import React, { useState, useEffect } from 'react';

function App() {
  const [amount, setAmount] = useState(0);
  const [category, setCategory] = useState('income');
  const [date, setDate] = useState('');
  const [transactions, setTransactions] = useState([]);
  const [filter, setFilter] = useState('all');

  useEffect(() => {
    const storedTransactions = localStorage.getItem('transactions');
    if (storedTransactions) {
      setTransactions(JSON.parse(storedTransactions));
    }
  }, []);

  const handleAmountChange = (event) => {
    setAmount(parseFloat(event.target.value));
  };

  const handleCategoryChange = (event) => {
    setCategory(event.target.value);
  };

  const handleDateChange = (event) => {
    setDate(event.target.value);
  };

  const handleFilterChange = (event) => {
    setFilter(event.target.value);
  };

  const handleSubmit = (event) => {
    event.preventDefault();

    if (isNaN(amount) || amount <= 0) {
      alert('Please enter a valid positive amount.');
      return;
    }

    const newTransaction = { amount, category, date };
    setTransactions([...transactions, newTransaction]);
    storeTransactions(newTransaction); // Call store function
    setAmount(0); // Clear amount after submission
  };

  const storeTransactions = (transaction) => {
    const updatedTransactions = [...transactions, transaction];
    localStorage.setItem('transactions', JSON.stringify(updatedTransactions));
  };

  const filteredTransactions = transactions.filter(
    (transaction) => filter === 'all' || transaction.category === filter
  );

  return (
    <div className="App">
      <h1>My Finance Tracker</h1>
      <form onSubmit={handleSubmit}>
        <label htmlFor="amount">Amount:</label>
        <input type="number" id="amount" value={amount} onChange={handleAmountChange} required />
        <label htmlFor="category">Category:</label>
        <select id="category" value={category} onChange={handleCategoryChange}>
          <option value="income">Income</option>
          <option value="expense">Expense</option>
        </select>
        <label htmlFor="date">Date:</label>
        <input type="date" id="date" value={date} onChange={handleDateChange} />
        <button type="submit">Add Transaction</button>
      </form>
      <select value={filter} onChange={handleFilterChange}>
        <option value="all">All</option>
        <option value="income">Income</option>
        <option value="expense">Expense</option>
      </select>
      <h2>Transactions</h2>
      <ul>
        {filteredTransactions.map((transaction) => (
          <li key={transaction.amount + transaction.date}>
            <span className={transaction.category}>{transaction.amount}</span>
            <span>{transaction.category}</span>
            <span>{transaction.date}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default App;
